package com.esercizio.venerdi21febbraio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Venerdi21febbraioApplication {

	public static void main(String[] args) {
		SpringApplication.run(Venerdi21febbraioApplication.class, args);
	}

}
