package com.esercizio.venerdi21febbraio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Venerdi21febbraioApplicationTests {

	@Test
	void contextLoads() {
	}

}
